﻿using System;
using System.Collections.Generic;

namespace JwtAuthentication.Server.Models;

public partial class Admin
{
    public string AdminName { get; set; } = null!;

    public string AdminPwd { get; set; } = null!;
}
